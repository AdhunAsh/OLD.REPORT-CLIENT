import React from "react";
import { Routes, Route, useLocation, Navigate } from "react-router-dom";
import Collection from "./pages/Collection";
import Home from "./pages/Home";
import Product from "./pages/Product";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Cart from "./pages/Cart";
import PlaceOrder from "./pages/PlaceOrder";
import Orders from "./pages/Orders";
import Footer from "./components/Footer";
import NavBar from "./components/NavBAr";
import SearchBar from "./components/SearchBar";
import { ToastContainer } from "react-toastify";
import {
  SignIn,
  SignUp,
  SignedIn,
  SignedOut,
  RedirectToSignIn,
} from "@clerk/clerk-react";

const App = () => {
  const location = useLocation();
  const hideLayout = ["/login", "/signup"].includes(location.pathname);

  return (
    <div className="px-4 sm:px-[5vw] md:px-[7vw] lg:px-[9vw]">
      <ToastContainer />

      {/* Hide NavBar & SearchBar on login/signup
      {!hideLayout && <NavBar />}
      {!hideLayout && <SearchBar />} */}

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/collection" element={<Collection />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/product/:productId" element={<Product />} />

        {/* Login & Signup with redirect if already signed in */}
        <Route
          path="/login"
          element={
            <>
              <SignedIn>
                <Navigate to="/" replace />
              </SignedIn>
              <SignedOut>
                <SignIn routing="path" path="/login" afterSignInUrl="/" />
              </SignedOut>
            </>
          }
        />
        <Route
          path="/signup"
          element={
            <>
              <SignedIn>
                <Navigate to="/" replace />
              </SignedIn>
              <SignedOut>
                <SignUp routing="path" path="/signup" afterSignUpUrl="/" />
              </SignedOut>
            </>
          }
        />

        {/* Protected: Cart */}
        <Route
          path="/cart"
          element={
            <>
              <SignedIn>
                <Cart />
              </SignedIn>
              <SignedOut>
                <RedirectToSignIn />
              </SignedOut>
            </>
          }
        />

        {/* Protected: Place Order */}
        <Route
          path="/placeorder"
          element={
            <>
              <SignedIn>
                <PlaceOrder />
              </SignedIn>
              <SignedOut>
                <RedirectToSignIn />
              </SignedOut>
            </>
          }
        />

        {/* Protected: Orders */}
        <Route
          path="/orders"
          element={
            <>
              <SignedIn>
                <Orders />
              </SignedIn>
              <SignedOut>
                <RedirectToSignIn />
              </SignedOut>
            </>
          }
        />
      </Routes>

      {/* Hide Footer on login/signup */}
      {!hideLayout && <Footer />}
    </div>
  );
};

export default App;